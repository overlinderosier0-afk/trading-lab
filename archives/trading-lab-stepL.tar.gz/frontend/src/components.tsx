import React from "react";

// ---------- Carte ----------
export function Card({ title, children, className = "" }: {
  title?: string; children: React.ReactNode; className?: string;
}) {
  return (
    <div className={`rounded-xl border border-slate-800 bg-slate-900/60 p-4 ${className}`}>
      {title && <h3 className="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-400">{title}</h3>}
      {children}
    </div>
  );
}

// ---------- Indicateur coloré ----------
export function Stat({ label, value, sub, tone = "neutral" }: {
  label: string; value: string; sub?: string;
  tone?: "neutral" | "pos" | "neg" | "warn";
}) {
  const colors = {
    neutral: "text-slate-100",
    pos: "text-emerald-400",
    neg: "text-rose-400",
    warn: "text-amber-400",
  };
  return (
    <div>
      <div className="text-xs uppercase tracking-wide text-slate-500">{label}</div>
      <div className={`mt-1 text-2xl font-bold ${colors[tone]}`}>{value}</div>
      {sub && <div className="mt-1 text-xs text-slate-500">{sub}</div>}
    </div>
  );
}

export function toneFor(v: number | null | undefined): "pos" | "neg" | "neutral" {
  if (v === null || v === undefined) return "neutral";
  return v > 0 ? "pos" : v < 0 ? "neg" : "neutral";
}

// ---------- Badge signal ----------
export function SignalBadge({ signal }: { signal: string }) {
  const styles: Record<string, string> = {
    BUY: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30",
    SELL: "bg-rose-500/15 text-rose-400 border-rose-500/30",
    HOLD: "bg-slate-500/15 text-slate-400 border-slate-500/30",
    long: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30",
    short: "bg-rose-500/15 text-rose-400 border-rose-500/30",
  };
  return (
    <span className={`inline-block rounded border px-2 py-0.5 text-xs font-semibold ${styles[signal] ?? styles.HOLD}`}>
      {signal}
    </span>
  );
}

// ---------- Badge statut d'edge d'une stratégie ----------
export function EdgeBadge({ status, note }: { status: string; note?: string }) {
  if (status === "NO_EDGE_DEMONSTRATED") {
    return (
      <div className="mt-2 rounded-lg border border-amber-600/50 bg-amber-950/40 px-3 py-2 text-xs text-amber-200">
        <span className="font-bold">⚠ Aucune preuve d'edge démontré — stratégie de démonstration uniquement.</span>
        {note && <span className="mt-1 block text-amber-200/70">{note}</span>}
      </div>
    );
  }
  if (status === "UNDER_REVIEW") {
    return (
      <div className="mt-2 rounded-lg border border-sky-600/50 bg-sky-950/40 px-3 py-2 text-xs text-sky-200">
        <span className="font-bold">En cours d'évaluation — ne pas utiliser pour trader.</span>
        {note && <span className="mt-1 block text-sky-200/70">{note}</span>}
      </div>
    );
  }
  return null;
}

// ---------- Graphique ligne SVG (sans dépendance) ----------
export function LineChart({ data, height = 220, color = "#34d399", formatY }: {
  data: { ts: string; value: number }[];
  height?: number;
  color?: string;
  formatY?: (v: number) => string;
}) {
  if (!data.length) return <div className="py-8 text-center text-sm text-slate-500">Aucune donnée</div>;
  const w = 900, h = height, pad = 10;
  const vals = data.map((d) => d.value);
  const min = Math.min(...vals), max = Math.max(...vals);
  const span = max - min || 1;
  const stepX = (w - pad * 2) / Math.max(1, data.length - 1);
  const pts = data
    .map((d, i) => `${(pad + i * stepX).toFixed(1)},${(h - pad - ((d.value - min) / span) * (h - pad * 2)).toFixed(1)}`)
    .join(" ");
  const fy = formatY ?? ((v: number) => v.toFixed(2));
  return (
    <div>
      <svg viewBox={`0 0 ${w} ${h}`} className="w-full" preserveAspectRatio="none" style={{ height }}>
        <polygon points={`${pad},${h - pad} ${pts} ${w - pad},${h - pad}`} fill={color} opacity={0.1} />
        <polyline points={pts} fill="none" stroke={color} strokeWidth={1.6} />
      </svg>
      <div className="mt-1 flex justify-between text-xs text-slate-500">
        <span>min {fy(min)}</span>
        <span>max {fy(max)}</span>
      </div>
    </div>
  );
}

// ---------- État de chargement / erreur ----------
export function Loading({ label = "Chargement…" }: { label?: string }) {
  return <div className="py-10 text-center text-sm text-slate-500">{label}</div>;
}

export function ErrorBox({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="rounded-xl border border-rose-900 bg-rose-950/40 p-4 text-sm text-rose-300">
      <div className="font-semibold">Erreur</div>
      <div className="mt-1 break-words">{message}</div>
      {onRetry && (
        <button onClick={onRetry} className="mt-3 rounded bg-rose-900 px-3 py-1 text-xs hover:bg-rose-800">
          Réessayer
        </button>
      )}
    </div>
  );
}

// ---------- Bouton ----------
export function Btn({ children, onClick, kind = "primary", disabled }: {
  children: React.ReactNode; onClick?: () => void;
  kind?: "primary" | "danger" | "ghost"; disabled?: boolean;
}) {
  const styles = {
    primary: "bg-blue-600 hover:bg-blue-500 text-white",
    danger: "bg-rose-700 hover:bg-rose-600 text-white",
    ghost: "bg-slate-800 hover:bg-slate-700 text-slate-200",
  };
  return (
    <button onClick={onClick} disabled={disabled}
      className={`rounded-lg px-4 py-2 text-sm font-semibold disabled:opacity-40 ${styles[kind]}`}>
      {children}
    </button>
  );
}

// ---------- Champ formulaire ----------
export function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs uppercase tracking-wide text-slate-500">{label}</span>
      {children}
    </label>
  );
}

export const inputCls =
  "w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-slate-100 focus:border-blue-500 focus:outline-none";
