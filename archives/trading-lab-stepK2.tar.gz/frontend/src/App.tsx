import { useState } from "react";
import Dashboard from "./tabs/Dashboard";
import Backtests from "./tabs/Backtests";
import Validation from "./tabs/Validation";
import Paper from "./tabs/Paper";
import Market from "./tabs/Market";
import System from "./tabs/System";

const TABS = [
  { id: "dashboard", label: "Dashboard" },
  { id: "backtests", label: "Backtests" },
  { id: "validation", label: "Validation" },
  { id: "paper", label: "Paper Trading" },
  { id: "market", label: "Marché" },
  { id: "system", label: "Système" },
];

export default function App() {
  const [tab, setTab] = useState("dashboard");
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <header className="border-b border-slate-800 bg-slate-900/80">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-3 px-4 py-3">
          <span className="text-xl">🌙</span>
          <h1 className="text-lg font-bold">Trading Lab</h1>
          <span className="rounded-md border border-amber-600/50 bg-amber-950/60 px-2 py-1 text-xs font-bold text-amber-300">
            PAPER TRADING — AUCUN ARGENT RÉEL
          </span>
        </div>
        <nav className="mx-auto flex max-w-7xl gap-1 overflow-x-auto px-4 pb-2">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`whitespace-nowrap rounded-lg px-4 py-2 text-sm font-semibold ${
                tab === t.id ? "bg-blue-600 text-white" : "text-slate-400 hover:bg-slate-800 hover:text-slate-200"
              }`}
            >
              {t.label}
            </button>
          ))}
        </nav>
      </header>
      <main className="mx-auto max-w-7xl px-4 py-4">
        {tab === "dashboard" && <Dashboard />}
        {tab === "backtests" && <Backtests />}
        {tab === "validation" && <Validation />}
        {tab === "paper" && <Paper />}
        {tab === "market" && <Market />}
        {tab === "system" && <System />}
      </main>
      <footer className="mx-auto max-w-7xl px-4 pb-6 text-center text-xs text-slate-600">
        Trading Lab — recherche et simulation. Backtest ≠ garantie de performance future.
      </footer>
    </div>
  );
}
