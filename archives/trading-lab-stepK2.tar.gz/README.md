# Trading Lab

Plateforme de recherche et simulation de trading (analyse, backtesting, paper trading).
**Aucun trade réel — par design, aucune clé de broker n'existe dans ce système.**

## État : étape K — validation anti sur-optimisation (IS/OOS + walk-forward)

`POST /api/validation/is-oos` (découpe IS/OOS, grille optimisée sur IS puis
évaluée sur OOS jamais vu, verdict : robuste / dégradé / sur-optimisé),
`POST /api/validation/walk-forward` (plis roulants : grille optimisée par pli
TRAIN, évaluée sur TEST), `GET /api/validation/runs`,
`GET /api/validation/runs/{id}`. Table `validation_runs`. Tests :
`backend/tests/` (18 tests : géométrie des plis, no-lookahead avec données
futures, sélection Sharpe, garde-fous de grille, câblage API, régression
`/health` avant le catch-all SPA). Nouvel onglet dashboard « Validation ».
Fix : `/health` et `/ready` enregistrés AVANT le catch-all SPA (avant, le
catch-all interceptait `/health` et retournait index.html).

## État : étape G — paper trading + risk + scheduler

Moteur de paper trading **virtuel uniquement** (aucun ordre réel possible par design) :
cycle toutes les 15 min sur la dernière bougie close (sync incrémental, signal,
stop/take, application du signal après garde-fous).
Risk management indépendant : kill switch manuel, activation explicite requise
(`POST /api/paper/start`, défaut OFF), max positions, perte journalière max,
circuit breaker drawdown (désactivation auto).
Scheduler APScheduler in-process : sync données toutes les 30 min, paper toutes
les 15 min. Tables : `paper_accounts`, `paper_positions`, `paper_trades`,
`signals`, `system_events`, `system_state`.
Endpoints : `/api/paper/*` (account, positions, trades, performance, signals,
start, stop), `/api/system/*` (status, events).

## Historique des étapes

- **F** — backtesting : `POST /api/backtests` (simulation barre par barre,
  frais+slippage, sizing risque), `GET /api/backtests`, `GET /api/backtests/{id}`.
- **C** — market data : `POST /api/market/sync` (backfill + incrémental Binance),
  `GET /api/market/status`, `GET /api/market/candles`.

- **C** — market data : `POST /api/market/sync` (backfill + incrémental Binance),
  `GET /api/market/status`, `GET /api/market/candles`.
- **D/E** — indicateurs (SMA, EMA, RSI, MACD, Bollinger, ATR, volume moyen) +
  stratégie démo `ema_rsi_demo` ; `GET /api/strategies`, `GET /api/signals`.

## Mise à jour du code (étapes suivantes)

L'archive ne contient jamais `.env` (ton mot de passe est en sécurité) :
```bash
cd ~
curl -L -o trading-lab.tar.gz '<URL>'
tar -xzf trading-lab.tar.gz -C trading-lab --strip-components=1 && rm trading-lab.tar.gz
cd ~/trading-lab
docker compose up -d --build
```

## Test market data

```bash
# synchro complète (défauts : BTCUSDT+ETHUSDT, 1h/4h/1d, 365 jours) — ~1 min
docker exec trading-lab-backend curl -sf -X POST http://localhost:8000/api/market/sync \
  -H 'Content-Type: application/json' -d '{}'
# état des données
docker exec trading-lab-backend curl -sf http://localhost:8000/api/market/status
# dernières bougies
docker exec trading-lab-backend curl -sf 'http://localhost:8000/api/market/candles?symbol=BTCUSDT&timeframe=1h&limit=3'
```

## Démarrage

```bash
cd ~/trading-lab
cp .env.example .env
# génère un mot de passe sûr et l'injecte aux 2 endroits :
PASS=$(openssl rand -hex 24) && sed -i "s/change-me-generate-strong/$PASS/g" .env
docker compose up -d --build
docker compose ps
docker exec trading-lab-backend curl -sf http://localhost:8000/health
docker exec trading-lab-backend curl -sf http://localhost:8000/ready
```

## Commandes utiles

```bash
docker compose ps                  # état des services
docker compose logs -f backend     # logs temps réel (JSON structurés)
docker compose logs --tail=50 postgres
docker compose down                # tout arrêter (données pgdata conservées)
docker compose down -v             # tout arrêter + SUPPRIMER les données (irréversible)
```

## Rollback étape B

```bash
cd ~/trading-lab && docker compose down -v && cd ~ && rm -rf ~/trading-lab
```

Le VPS revient exactement à son état d'avant.
